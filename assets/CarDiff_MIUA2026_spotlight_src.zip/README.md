# CarDiff — MIUA 2026 Research Spotlight (3-slide deck)

Backdrop slides for the optional **MIUA 2026 Research Spotlight** — a **≤ 60-second** video
(3 slides: Motivation · Technical Innovation · Potential Impact).

- **Format:** 16:9, 3 slides → `spotlight.pdf`
- **Engine:** pdfLaTeX. **Build:** `pdflatex spotlight.tex` **run twice** (the header band
  uses TikZ `remember picture` overlays that need a second pass).

## How to submit (from the organisers' email)
1. Record a **max 60-second** talk over these 3 slides (screen-record with your webcam/voice,
   or narrate the PDF).
2. Upload to **YouTube** (public or unlisted).
3. Email the YouTube link to **miua2026@ucd.ie** by **16 July 2026**.

## Suggested narration (~55 s, ~150 words)

**Slide 1 — Motivation (~18 s)**
> Dental caries is the most common disease in the world, and catching it early on X-rays
> really matters. But AI for caries is held back by two things: too few annotated images,
> and severe class imbalance. In our dataset, deep caries dominate, while the early
> superficial and medium lesions — the ones we most want to catch — are rare, so models
> segment them poorly.

**Slide 2 — Technical Innovation (~20 s)**
> We introduce CarDiff, a segmentation-guided latent diffusion model that synthesizes
> realistic dental radiographs from lesion masks. It trains along two paths — paired and
> self-supervised — and adds anatomy-aware conditioning: a patch-graph neural network with
> global attention, injected through FiLM, plus consistency and adversarial losses. CarDiff
> reaches the best FID and LPIPS among four baselines — the most realistic synthesis.

**Slide 3 — Potential Impact (~17 s)**
> Why does this matter? Using CarDiff images to augment training five-fold improves caries
> segmentation across seven architectures — up to six-and-a-half percent average Dice, with
> the biggest gains on the rare, early lesions. It's a step toward trustworthy AI-assisted
> diagnosis when data is scarce. Thank you.

## Files
```
spotlight.tex        # the 3 slides
spotlight.pdf        # compiled deck (final)
figs/framework.pdf   # slide 2 — CarDiff framework
figs/mosaic.pdf      # slide 3 — qualitative comparison
figs/pie.pdf         # slide 1 — class distribution
figs/au_logo.png     # Aarhus University logo (header)
```

## Editing
Author line, conference tag and GitHub link live in the `\slidefoot` / `\slidehead` macros
near the top of `spotlight.tex`. Palette colours (`cdnavy`, `cdteal`, `cdblue`, `cdred`) are
shared with the poster.
