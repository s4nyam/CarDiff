# CarDiff — MIUA 2026 Conference Poster

LaTeX source for the **CarDiff** poster, prepared to the **official MIUA 2026 poster
guidelines** (https://www.ucd.ie/medicine/miua2026/calls/faqs/).

## Guideline compliance (checked)
| MIUA 2026 requirement | This poster |
|---|---|
| Portrait, **not exceeding A0** | A0 **portrait**, exactly 841 mm × 1189 mm ✔ |
| Title & author information | Header ✔ |
| Background & motivation | Block 1 ✔ |
| Methods | Blocks 3, 5 — Framework, Dataset (teal) ✔ |
| Results | Blocks 4, 6 — Qualitative, Synthesis+Augmentation (blue) ✔ |
| Conclusions | Block 7 ✔ |
| QR code to paper/code (optional) | Header QR → GitHub repo ✔ |

Conference: **MIUA 2026 — Medical Image Understanding & Analysis, University College
Dublin, Ireland, 20–22 July 2026.**

- **Class:** `beamer` + `beamerposter` (blocks styled with `tcolorbox`).
- **Compiler:** **pdfLaTeX** (also builds with LuaLaTeX). No bibliography step needed.

## Build on Overleaf
1. **New Project → Upload Project** and upload `CarDiff_MIUA2026_Poster.zip`.
2. In **Menu**, set **Compiler = pdfLaTeX** and **Main document = `poster.tex`**.
3. Click **Recompile**. Output is a single A0 page.

## Build locally
```bash
pdflatex poster.tex     # one run is enough (two runs are harmless)
```

## Printing (per the MIUA FAQ)
You can email the A0 PDF to UCD Copi-Print (`posters@ucd.ie`); ~€35 for A0, pay on
collection (Newman Building, J/K Area; open from 10:00 on Mon 20 July 2026).

## Files
```
poster.tex          # the poster
figs/framework.pdf  # dual-path framework overview (hero diagram)
figs/mosaic.pdf     # qualitative comparison vs. baselines (hero diagram)
figs/pie.pdf        # caries class distribution (motivation)
figs/au_logo.png    # Aarhus University logo (header)
figs/auth_*.jpg     # author headshots (Sanyam, Bruna, Alex, Ruben)
```

## How to edit

**Author names / photos** — edit the `\authorcell{photo}{name}{aff-superscript}` calls in
the header. Names come from the submitted paper; photos are the authors' official portraits
(AU profile pages / TUNI news page), cropped to squares and clipped to circles at build
time. To swap a photo, replace the matching `figs/auth_*.jpg` (any square image works).
**Affiliations / contact** are the two macros near the top marked `>>> AUTHOR DETAILS <<<`
(`\afflines`, `\contactline`).

**QR code** — encodes `https://github.com/s4nyam/CarDiff` (paper, code & data); it is the
only code reference on the poster. Change the target in the `\qrcode{...}` call in the header.

**Institution logo** — `figs/au_logo.png` (Aarhus University) sits on a white box in the
header. Replace that file to use a different logo.

**Section colour scheme** — navy = framing (Background, Contributions, Conclusions),
**teal = Methods**, **blue = Results** (also shown in the footer key). Change a block's
colour via its optional argument, e.g. `\begin{cblock}[cdteal]{...}`. Palette colours
(`cdnavy`, `cdteal`, `cdblue`, `cdred`, …) are defined once in the preamble.

**Change poster size** — edit the `beamerposter` options in the preamble (e.g. `size=a1`).
A0 portrait is the MIUA maximum, so keep it at A0 or smaller. After any size change,
re-check that nothing overflows.

### Notes
- Every displayed equation is wrapped in `\fiteq{...}`, which auto-scales it to the column
  width so it can never overflow horizontally.
- Section blocks are numbered 1–9 to guide the reading order (column 1 → 2 → 3).
- The optional MIUA **Research Spotlight** (a separate 1-minute video: Motivation /
  Technical Innovation / Potential Impact) is *not* part of the poster.
